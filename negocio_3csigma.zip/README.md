# negocio_3csigma
 Plataforma de Automatización de documentos
